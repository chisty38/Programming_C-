﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//namespace LinkedListEmployee
//{
    class LinkedListEmployeeTest
    {
        static void Main(string[] args)
        {
           //LinkedListEmployeeTest emp = new LinkedListEmployeeTest
        }
    }
//}
