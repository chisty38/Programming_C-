﻿namespace Ex_02
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.managerLabel = new System.Windows.Forms.Label();
            this.tellerLabel = new System.Windows.Forms.Label();
            this.creditLabel = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.newCus = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.button2 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.button3 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.managerDisplay = new System.Windows.Forms.TextBox();
            this.tellerDisplay = new System.Windows.Forms.TextBox();
            this.creditDisplay = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(56, 32);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(43, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Serving";
            // 
            // managerLabel
            // 
            this.managerLabel.AutoSize = true;
            this.managerLabel.Location = new System.Drawing.Point(27, 60);
            this.managerLabel.Name = "managerLabel";
            this.managerLabel.Size = new System.Drawing.Size(19, 13);
            this.managerLabel.TabIndex = 1;
            this.managerLabel.Text = "----";
            // 
            // tellerLabel
            // 
            this.tellerLabel.AutoSize = true;
            this.tellerLabel.Location = new System.Drawing.Point(66, 60);
            this.tellerLabel.Name = "tellerLabel";
            this.tellerLabel.Size = new System.Drawing.Size(19, 13);
            this.tellerLabel.TabIndex = 2;
            this.tellerLabel.Text = "----";
            // 
            // creditLabel
            // 
            this.creditLabel.AutoSize = true;
            this.creditLabel.Location = new System.Drawing.Point(109, 60);
            this.creditLabel.Name = "creditLabel";
            this.creditLabel.Size = new System.Drawing.Size(19, 13);
            this.creditLabel.TabIndex = 3;
            this.creditLabel.Text = "----";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(41, 186);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Incoming Customer";
            // 
            // newCus
            // 
            this.newCus.Location = new System.Drawing.Point(55, 240);
            this.newCus.Name = "newCus";
            this.newCus.Size = new System.Drawing.Size(57, 28);
            this.newCus.TabIndex = 5;
            this.newCus.Text = "New";
            this.newCus.UseVisualStyleBackColor = true;
            this.newCus.Click += new System.EventHandler(this.newCus_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(380, 32);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(61, 13);
            this.label2.TabIndex = 6;
            this.label2.Text = "MANAGER";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(368, 72);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 7;
            this.button1.Text = "NEXT";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(380, 175);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(48, 13);
            this.label3.TabIndex = 8;
            this.label3.Text = "TELLER";
            // 
            // button2
            // 
            this.button2.Location = new System.Drawing.Point(368, 216);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 9;
            this.button2.Text = "NEXT";
            this.button2.UseVisualStyleBackColor = true;
            this.button2.Click += new System.EventHandler(this.button2_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(365, 307);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(95, 13);
            this.label4.TabIndex = 10;
            this.label4.Text = "CREDIT OFFICER";
            // 
            // button3
            // 
            this.button3.Location = new System.Drawing.Point(368, 349);
            this.button3.Name = "button3";
            this.button3.Size = new System.Drawing.Size(75, 23);
            this.button3.TabIndex = 11;
            this.button3.Text = "NEXT";
            this.button3.UseVisualStyleBackColor = true;
            this.button3.Click += new System.EventHandler(this.button3_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(594, 32);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(36, 13);
            this.label6.TabIndex = 12;
            this.label6.Text = "WITH";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(595, 175);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(36, 13);
            this.label7.TabIndex = 13;
            this.label7.Text = "WITH";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(597, 306);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(36, 13);
            this.label8.TabIndex = 14;
            this.label8.Text = "WITH";
            // 
            // managerDisplay
            // 
            this.managerDisplay.Location = new System.Drawing.Point(564, 72);
            this.managerDisplay.Name = "managerDisplay";
            this.managerDisplay.Size = new System.Drawing.Size(100, 20);
            this.managerDisplay.TabIndex = 15;
            // 
            // tellerDisplay
            // 
            this.tellerDisplay.Location = new System.Drawing.Point(564, 218);
            this.tellerDisplay.Name = "tellerDisplay";
            this.tellerDisplay.Size = new System.Drawing.Size(100, 20);
            this.tellerDisplay.TabIndex = 16;
            // 
            // creditDisplay
            // 
            this.creditDisplay.Location = new System.Drawing.Point(564, 351);
            this.creditDisplay.Name = "creditDisplay";
            this.creditDisplay.Size = new System.Drawing.Size(100, 20);
            this.creditDisplay.TabIndex = 17;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.creditDisplay);
            this.Controls.Add(this.tellerDisplay);
            this.Controls.Add(this.managerDisplay);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.button3);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.button2);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.newCus);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.creditLabel);
            this.Controls.Add(this.tellerLabel);
            this.Controls.Add(this.managerLabel);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label managerLabel;
        private System.Windows.Forms.Label tellerLabel;
        private System.Windows.Forms.Label creditLabel;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button newCus;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button button3;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox managerDisplay;
        private System.Windows.Forms.TextBox tellerDisplay;
        private System.Windows.Forms.TextBox creditDisplay;
    }
}

