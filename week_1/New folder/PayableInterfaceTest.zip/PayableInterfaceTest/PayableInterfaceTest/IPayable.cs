﻿// Fig. 12.11: IPayable.cs
// IPayable interface declaration.
public interface IPayable
{
   decimal GetPaymentAmount(); // calculate payment; no implementation
}


